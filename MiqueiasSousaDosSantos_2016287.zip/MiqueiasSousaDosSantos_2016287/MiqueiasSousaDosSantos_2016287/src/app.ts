import { getAuthController } from "./backend/controllers/auth_controller";
import { Connection } from "./db";
import express from "express";
import bodyParser from "body-parser";
import { getUserController } from "./backend/controllers/user_controller";
import { getLinkController } from "./backend/controllers/link_controller";
import { getCommentController } from "./backend/controllers/comment_controller";

/*
 * Name: Miqueias Sousa dos Santos
 * Student Number: 2016287
 */

(async () => {

    await Connection();

    const app = express();

    app.use(bodyParser.json());
    app.use(bodyParser.urlencoded({ extended: true }));

    app.get("/", (req, res) => {
        res.send("This is the home page!");
    });

    const authController = getAuthController();
    const usersController = getUserController();
    const linksController = getLinkController();
    const commentController = getCommentController();

    app.use("/api/v1/comments", commentController);
    app.use("/api/v1/users", usersController);
    app.use("/api/v1/auth", authController);
    app.use("/api/v1/links", linksController);

    app.listen(8080, () => {
        console.log(
            "The server is running in port 8080!"
        );
    });

})();