/*
 * Name: Miqueias Sousa dos Santos
 * Student Number: 2016287
 */

// To Login into -- OK
(async () => {
    const data = {
        email: "remo.jansen@wolksoftware.com",
        password: "test123"
    }
    const response = await fetch(
        "http://localhost:8080/api/v1/auth/login",
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json; charset=UTF-8"
            },
            body: JSON.stringify(data)
        }
    );
    const json = await response.json();
    console.log(json);
})();

// To Register -- OK
(async () => {
    const data = {
        email: "remo.jansen@wolksoftware.com",
        password: "test123"
    }
    const response = await fetch(
        "http://localhost:8080/api/v1/users/",
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json; charset=UTF-8"
            },
            body: JSON.stringify(data)
        }
    );
    const json = await response.json();
    console.log(json);
})();

// To creating a new link (post) -- OK
(async () => {
    const data = {
        adressUrl: "post_one_test",
        title: "Podt One Test"
    }
    const response = await fetch(
        "http://localhost:8080/api/v1/links/",
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json; charset=UTF-8",
                "x-auth-token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiaWF0IjoxNTQ4NTM0MjA2fQ.VSPQyFGZAsEUo0PeQj8gLspkeyJ-m97RGfLa2TBQd4w"
            },
            body: JSON.stringify(data)
        }
    );
    const json = await response.json();
    console.log(json);
})();

// To delete link -- OK
(async () => {

    const response = await fetch(
        "http://localhost:8080/api/v1/links/1",
        {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json; charset=UTF-8",
                "x-auth-token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiaWF0IjoxNTQ4NTM0MjA2fQ.VSPQyFGZAsEUo0PeQj8gLspkeyJ-m97RGfLa2TBQd4w"
            }
        }
    );
    const json = await response.json();
    console.log(json);
})();

// To vote deslike on link
(async () => {

    const response = await fetch(
        "http://localhost:8080/api/v1/links/1/downvote",
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json; charset=UTF-8",
                "x-auth-token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiaWF0IjoxNTQ4NTM0MjA2fQ.VSPQyFGZAsEUo0PeQj8gLspkeyJ-m97RGfLa2TBQd4w"
            }
        }
    );
    const json = await response.json();
    console.log(json);
})();

// To vote up like on link
(async () => {

    const response = await fetch(
        "http://localhost:8080/api/v1/links/1/upvote",
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json; charset=UTF-8",
                "x-auth-token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiaWF0IjoxNTQ4NTM0MjA2fQ.VSPQyFGZAsEUo0PeQj8gLspkeyJ-m97RGfLa2TBQd4w"
            }
        }
    );
    const json = await response.json();
    console.log(json);
})();

// To vote down like on link
(async () => {

    const response = await fetch(
        "http://localhost:8080/api/v1/links/1/downvote",
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json; charset=UTF-8",
                "x-auth-token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiaWF0IjoxNTQ4NTM0MjA2fQ.VSPQyFGZAsEUo0PeQj8gLspkeyJ-m97RGfLa2TBQd4w"
            }
        }
    );
    const json = await response.json();
    console.log(json);
})();

// To create a new comment in a post -- OK
(async () => {
    const data = {
        text: "Comment on post One Test",
        link_id: 1
    }
    const response = await fetch(
        "http://localhost:8080/api/v1/comments/",
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json; charset=UTF-8",
                "x-auth-token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiaWF0IjoxNTQ4NTM0MjA2fQ.VSPQyFGZAsEUo0PeQj8gLspkeyJ-m97RGfLa2TBQd4w"
            },
            body: JSON.stringify(data)
        }
    );
    const json = await response.json();
    console.log(json);
})();

// To delete a comment of a post -- OK
(async () => {
    const response = await fetch(
        "http://localhost:8080/api/v1/comments/1",
        {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json; charset=UTF-8",
                "x-auth-token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiaWF0IjoxNTQ4NTM0MjA2fQ.VSPQyFGZAsEUo0PeQj8gLspkeyJ-m97RGfLa2TBQd4w"
            }
        }
    );
    const json = await response.json();
    console.log(json);
})();

// To edit a comment of a post -- OK
(async () => {
    const data = {
        text: "Exactly."
    }
    const response = await fetch(
        "http://localhost:8080/api/v1/comments/1",
        {
            method: "PATCH",
            headers: {
                "Content-Type": "application/json; charset=UTF-8",
                "x-auth-token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiaWF0IjoxNTQ4NTM0MjA2fQ.VSPQyFGZAsEUo0PeQj8gLspkeyJ-m97RGfLa2TBQd4w"
            },
            body: JSON.stringify(data)
        }
    );
    const json = await response.json();
    console.log(json);
})();