import { Entity, Column, PrimaryGeneratedColumn, OneToMany } from "typeorm";
import { Comment } from "./comment";
import { Link } from "./link";
import { Vote } from "./vote";

/*
 * Name: Miqueias Sousa dos Santos
 * Student Number: 2016287
 */

@Entity()
    export class User {
    @PrimaryGeneratedColumn()
    public id!: number;

    @Column()
    public email!: string;

    @Column()
    public password!: string;

    @OneToMany(type => Comment, comment => comment.user)
    public comment!: Comment[];

    @OneToMany(type => Link, link => link.user)
    public link!: Link[];
    
    @OneToMany(type => Vote, vote => vote.user)
    public vote!: Vote[];
}