import { Entity, Column, PrimaryGeneratedColumn, JoinColumn, ManyToOne } from "typeorm";
import { Link } from "./link";
import { User } from "./user";

/*
 * Name: Miqueias Sousa dos Santos
 * Student Number: 2016287
 */

@Entity()
export class Comment {
    @PrimaryGeneratedColumn()
    public id!: number;

    @Column()
    public text!: string;

    @ManyToOne(type => User, user => user.comment)
    @JoinColumn({ name: "user_id" })
    public user!: User;
    @Column({ nullable: false })
    user_id!: number;

    @ManyToOne(type => Link, link => link.comment)
    @JoinColumn({ name: "link_id" })
    public link!: Link;
    @Column({ nullable: false })
    link_id!: number;

}