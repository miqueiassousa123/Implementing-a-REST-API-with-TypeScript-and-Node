import { Entity, Column, PrimaryGeneratedColumn, OneToMany, JoinColumn, ManyToOne } from "typeorm";
import { Comment } from "./comment";
import { Vote } from "./vote";
import { User } from "./user";

/*
 * Name: Miqueias Sousa dos Santos
 * Student Number: 2016287
 */

@Entity()
export class Link {
    @PrimaryGeneratedColumn() 
    public id!: number;

    @Column()
    public title!: string;

    @Column()
    public adressUrl!: string;

    @OneToMany(type => Comment, comment => comment.link)
    public comment!: Comment[];

    @OneToMany(type => Vote, vote => vote.link)
    public vote!: Vote[];

    @ManyToOne(type => User, user => user.link)
    @JoinColumn({ name: "user_id" })
    public user!: User;
    @Column({ nullable: false })
    user_id!: number;
}