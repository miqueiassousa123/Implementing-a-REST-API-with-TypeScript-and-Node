import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, JoinColumn } from "typeorm";
import { User } from "./user";
import { Link } from "./link";

/*
 * Name: Miqueias Sousa dos Santos
 * Student Number: 2016287
 */

@Entity()
export class Vote {
    @PrimaryGeneratedColumn()
    public id!: number;

    @Column()
    public vote!: boolean;

    @ManyToOne(type => User, user => user.vote)
    @JoinColumn({ name: "user_id" })
    public user!: User;
    @Column({ nullable: false })
    user_id!: number;

    @ManyToOne(type => Link, link => link.vote)
    @JoinColumn({ name: "link_id" })
    public link!: Link;
    @Column({ nullable: false })
    link_id!: number;
}