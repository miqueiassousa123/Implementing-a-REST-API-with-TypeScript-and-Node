import { getConnection } from "typeorm";
import { Link } from "../entities/link";

/*
 * Name: Miqueias Sousa dos Santos
 * Student Number: 2016287
 */

export function getLinkRepository() {
    const connection = getConnection();
    const linkRepository = connection.getRepository(Link);
    return linkRepository;
}