import { getConnection } from "typeorm";
import { Vote } from "../entities/vote";

/*
 * Name: Miqueias Sousa dos Santos
 * Student Number: 2016287
 */

export function getVoteRepository() {
    const connection = getConnection();
    const voteRepository = connection.getRepository(Vote);
    return voteRepository;
}