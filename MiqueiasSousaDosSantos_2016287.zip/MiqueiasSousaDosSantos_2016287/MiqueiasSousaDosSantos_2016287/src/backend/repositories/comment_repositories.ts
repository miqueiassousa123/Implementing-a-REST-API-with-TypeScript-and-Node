import { Comment } from "../entities/comment";
import { getConnection } from "typeorm";

/*
 * Name: Miqueias Sousa dos Santos
 * Student Number: 2016287
 */

export function getCommentRepository() {
    const connection = getConnection();
    const commentRepository = connection.getRepository(Comment);
    return commentRepository;
}