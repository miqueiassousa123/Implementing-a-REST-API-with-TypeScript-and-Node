import { getConnection } from "typeorm";
import { User } from "../entities/user";

/*
 * Name: Miqueias Sousa dos Santos
 * Student Number: 2016287
 */

export function getUserRepository() {
    const connection = getConnection();
    const userRepository = connection.getRepository(User);
    return userRepository;
}