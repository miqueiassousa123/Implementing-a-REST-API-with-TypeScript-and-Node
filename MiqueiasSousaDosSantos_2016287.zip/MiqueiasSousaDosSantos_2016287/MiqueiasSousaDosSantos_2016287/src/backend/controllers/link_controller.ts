import * as express from "express";
import { getVoteRepository } from "../repositories/vote_repositories";
import { getLinkRepository } from "../repositories/link_repositories";
import * as joi from "joi";
import { authMiddleware } from "../middleware/auth_middleware";
import { getCommentRepository } from "../repositories/comment_repositories";

/*
 * Name: Miqueias Sousa dos Santos
 * Student Number: 2016287
 */

export function getLinkController() {
    const voteRepository = getVoteRepository();

    const linkRepository = getLinkRepository();

    const commentRepository = getCommentRepository();

    const router = express.Router();

    const linkSchemaForPost = {
        adressUrl: joi.string(),
        title: joi.string()
    };

    // POST http://localhost:8080/api/v1/links/
    router.post("/",authMiddleware, (req, res) => {
        (async () => {

            const NLink = req.body;
            const userid = (req as any).userId;
            const linkDone = {...NLink, user_id: userid, user: {id:userid}};

            const result = joi.validate(req.body, linkSchemaForPost);
            console.log(linkDone);
            if (result.error) {
                res.status(400).send({ msg: "Bed Request" });
            } else {
                const link = await linkRepository.save(linkDone);
                res.json(link);
            }
        })();
    });

    // DELETE http://localhost:8080/api/v1/links/1
    router.delete("/:id", authMiddleware, (req, res) => {
        (async () => {

            const id = req.params.id;
            const theLink = await linkRepository.findOne(id);

            if (theLink) {
                const userid = (req as any).userId;
                if (theLink.user_id == userid) {
                    const link = await linkRepository.delete(id);
                    res.json(link);
                } 
                else {
                    res.status(401).send({ msg: "Unauthorized" });
                }
            } else {
                res.status(404).send({ msg: "Link does not exist" });
            }
        })();
    });

    // http://localhost:8080/api/v1/links/
    router.get("/", (req, res) => {
        (async () => {

            const links = await linkRepository.find();
            res.json(links);
        })();
    });

    // http://localhost:8080/api/v1/links/1
    router.get("/:id", (req, res) => {
        (async () => {

            const idLink = parseInt(req.params.id);
            const theLink = await linkRepository.findOne(idLink);

            if (theLink) {
                const comments = await commentRepository.find({link_id: idLink});
                const votes = await voteRepository.find({link_id: idLink});
                const all = {theLink, votes, comments}
                res.json(all);
            } else {
                res.status(404).send({ msg: "Link does not exist" });
            }

        })();
    });

    // HTTP POST http://localhost:8080/api/v1/links/2/downvote
    router.post("/:id/downvote", authMiddleware, (req, res) => {
        (async () => {

            const idLink = parseInt(req.params.id);
            const userid = (req as any).userId;
            const theLink = await linkRepository.findOne(idLink);

            if (theLink) {
                const voted = await voteRepository.findOne({link_id: idLink, user_id: userid});
                if (voted) {
                    res.status(400).send({ msg: "You voted already" });
                } else {
                    const newVote = {vote: false, user_id: userid, link_id: idLink};
                    const vote = await voteRepository.save(newVote);
                    res.json(vote);
                }
            } else {
                res.status(404).send({ msg: "Link does not exist" });
            }

        })();
    });

    // HTTP POST http://localhost:8080/api/v1/links/2/upvote
    router.post("/:id/upvote", authMiddleware, (req, res) => {
        (async () => {

            const idLink = parseInt(req.params.id);
            const userid = (req as any).userId;
            const theLink = await linkRepository.findOne(idLink);

            if (theLink) {
                const voted = await voteRepository.findOne({link_id: idLink, user_id: userid});
                if (voted) {
                    res.status(400).send({ msg: "You voted already" });
                } else {
                    const newVote = {vote: true, user_id: userid, link_id: idLink};
                    const vote = await voteRepository.save(newVote);
                    res.json(vote);
                }
            } else {
                res.status(404).send({ msg: "Link does not exist" });
            }

        })();
    });

    return router;
}