import * as express from "express";
import { getCommentRepository } from "../repositories/comment_repositories";
import { authMiddleware } from "../middleware/auth_middleware";
import * as joi from "joi";

/*
 * Name: Miqueias Sousa dos Santos
 * Student Number: 2016287
 */

export function getCommentController() {

    const commentRepository = getCommentRepository();
    
    const router = express.Router();

    const commentSchemaForPost = {
        text: joi.string(),
        link_id: joi.number().greater(0)
    };

    const editSchemaForPost = {
        text: joi.string()
    };


    // http://localhost:8080/api/v1/comments/1
    router.delete("/:id", authMiddleware, (req, res) => {
        (async () => {
            const userId = (req as any).userId;
            const comentId = req.params.id;
            const theComment =  await commentRepository.findOne(comentId);

            if(theComment){
                if (theComment.user_id == userId) {
                    const comment = await commentRepository.delete(comentId);
                    res.json(comment);
                } else {
                    res.status(400).send({ msg: "This comment it is not yours" });
                }
            } else {
                res.status(404).send({ msg: "Commentary was not found!" });
            }

        })();
    });
   

    // http://localhost:8080/api/v1/comments/1
    router.patch("/:id", authMiddleware, (req, res) => {
        (async () => {
            const commentId = req.params.id;

            const theComment =  await commentRepository.findOne(commentId);
            var commentOk = false;

            if (theComment) {
                commentOk = true;
            }

            if(commentOk){
                const update = req.body;
                const userId = (req as any).userId;
                if (theComment) {
                    if (theComment.user_id == userId) {

                        const result = joi.validate(req.body, editSchemaForPost);
                        if (result.error) {
                            res.status(400).send({ msg: "Comment fild is not valid!" });
                        } else {
                            const key = Object.keys(update)[0];
                            const val = update[key];
                            (theComment as any)[key] = val;
                            const comment = await commentRepository.save(theComment);
                            res.json(comment);
                        }

                    } else {
                        res.status(400).send({ msg: "This comment it is not yours" });
                    }
                }

            } else {
                res.status(404).send({ msg: "Comment is not found!" });
            }

        })();
    });

    // POST http://localhost:8080/api/v1/comments/
    router.post("/", authMiddleware, (req, res) => {
        (async () => {
            const userId = (req as any).userId;
            const NComment = req.body;
            const commentDone = {user_id: userId, ...NComment};
            const result = joi.validate(req.body, commentSchemaForPost);

            if (result.error) {
                res.status(400).send({ msg: "Comment content is not valid!" });
            } else {
                const comment = await commentRepository.save(commentDone);
                res.json(comment);
            }
        })();
    });

    return router;
}