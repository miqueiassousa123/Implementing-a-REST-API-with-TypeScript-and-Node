import * as express from "express";
import * as joi from "joi";
import { getUserRepository } from "../repositories/user_repositories";
import { getCommentRepository } from "../repositories/comment_repositories";
import { getVoteRepository } from "../repositories/vote_repositories";
import { getLinkRepository } from "../repositories/link_repositories";

/*
 * Name: Miqueias Sousa dos Santos
 * Student Number: 2016287
 */

export function getUserController() {

    const userRepository = getUserRepository();

    const commentRepository = getCommentRepository();

    const linkRepository = getLinkRepository();
    
    const voteRepository = getVoteRepository();

    const router = express.Router();

    const userDetailsSchema = {
        email: joi.string().email(),
        password: joi.string()
    };

    // http://localhost:8080/api/v1/users/1
    router.get("/:id", (req, res) => {
        (async () => {

            const userId = parseInt(req.params.id);

            const user = await userRepository.findOne(userId);

            if (user) {
                const links = await linkRepository.find({user_id:userId});

                const comments = await commentRepository.find({user_id:userId});
    
                const votes = await voteRepository.find({user_id:userId});
    
                const all = {userId:userId, links, comments, votes};
    
                res.json(all);

            } else {
                res.status(404).send({ msg: "Comment is not found!" });
            }

        })();
    });


    // http://localhost:8080/users/
    router.post("/", (req, res) => {
        (async () => {
            const new_user = req.body;
            const test = joi.validate(new_user, userDetailsSchema);
            if (test.error) {
                res.status(400).send();
            } else {
                await userRepository.save(new_user);
                res.json({ok: "ok"}).send();
            }
        })();
    });

    return router;
}