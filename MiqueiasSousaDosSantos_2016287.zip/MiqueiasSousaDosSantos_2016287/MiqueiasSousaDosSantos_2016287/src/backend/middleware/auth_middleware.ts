import jwt from "jsonwebtoken";
import * as express from "express";

/*
 * Name: Miqueias Sousa dos Santos
 * Student Number: 2016287
 */

export function authMiddleware(
    req: express.Request,
    res: express.Response,
    next: express.NextFunction
) {
const AUTH_SECRET = process.env.AUTH_SECRET;
const token = req.headers["x-auth-token"];
    if (typeof token !== "string") {
        res.status(400).send();
    } else {
        if (AUTH_SECRET === undefined) {
            res.status(500).send();
        } else {
            try {
                const test = jwt.verify(token, AUTH_SECRET) as any;
                (req as any).userId = test.id;
                next();
            } catch(err) {
                res.status(403).send("Forbidden");
            }
        }
    }
}